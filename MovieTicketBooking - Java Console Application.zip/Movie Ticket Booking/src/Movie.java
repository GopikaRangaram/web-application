//interface Movie for storing Movie details
public interface Movie {
	public void addMovieDetails();
}
