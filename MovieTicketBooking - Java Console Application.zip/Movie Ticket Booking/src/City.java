//interface City for storing City details
public interface City {
	public void addCity();
}