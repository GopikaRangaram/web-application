//interface Theatre for storing Theatre details
interface Theatre {
	public void addTheatre();
}