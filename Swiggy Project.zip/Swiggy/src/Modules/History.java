package Modules;

public class History extends Person{
	String s;
	String d;
	int f;
	int con;
	History(int id,long cont,String s,String des,int fare)
	{
		this.id=id;
		this.contact=cont;
		this.s=s;
		this.d=des;
		this.f=fare;
	}
	
	
}
